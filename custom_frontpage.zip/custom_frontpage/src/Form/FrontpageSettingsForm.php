<?php

namespace Drupal\custom_frontpage\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class FrontpageSettingsForm extends ConfigFormBase {

  public function getFormId() {
    return 'custom_frontpage_settings_form';
  }

  protected function getEditableConfigNames() {
    return ['custom_frontpage.settings'];
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('custom_frontpage.settings');

    $form['enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable Custom Front Page'),
      '#default_value' => $config->get('enabled'),
    ];

    $form['html_content'] = [
      '#type' => 'text_format',
      '#title' => $this->t('HTML Content'),
      '#format' => $config->get('format') ?: 'full_html',
      '#default_value' => $config->get('html_content'),
      '#description' => $this->t('The HTML content of your custom front page.'),
    ];

    $form['custom_css'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Custom CSS'),
      '#default_value' => $config->get('custom_css'),
      '#description' => $this->t('Additional CSS to apply on the front page.'),
    ];

    $form['custom_js'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Custom JS'),
      '#default_value' => $config->get('custom_js'),
      '#description' => $this->t('Additional JavaScript to apply on the front page.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('custom_frontpage.settings')
      ->set('enabled', $form_state->getValue('enabled'))
      ->set('html_content', $form_state->getValue(['html_content', 'value']))
      ->set('format', $form_state->getValue(['html_content', 'format']))
      ->set('custom_css', $form_state->getValue('custom_css'))
      ->set('custom_js', $form_state->getValue('custom_js'))
      ->save();

    parent::submitForm($form, $form_state);
  }
}
