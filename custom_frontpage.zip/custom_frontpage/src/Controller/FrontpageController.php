<?php

namespace Drupal\custom_frontpage\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Response;

class FrontpageController extends ControllerBase {

  public function view() {
    $config = $this->config('custom_frontpage.settings');

    if (!$config->get('enabled')) {
      return new Response('<h1>Custom front page is disabled.</h1>', 200);
    }

    // Pull HTML content from CKEditor
    $htmlContent = $config->get('html_content') ?: '<h1>Welcome to your custom front page!</h1>';
    $format = $config->get('format');
    $htmlContent = check_markup($htmlContent, $format);

    // Pull custom CSS and JS
    $customCss = $config->get('custom_css') ?: '';
    $customJs = $config->get('custom_js') ?: '';

    $siteName = $this->config('system.site')->get('name');

    // Full dynamic HTML page
    $fullHtml = '<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>' . $siteName . '</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    ' . $customCss . '
  </style>
</head>
<body>
  <div class="custom-frontpage container mt-5">
    ' . $htmlContent . '
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    ' . $customJs . '
  </script>
</body>
</html>';

    return new Response($fullHtml, 200);
  }

}
